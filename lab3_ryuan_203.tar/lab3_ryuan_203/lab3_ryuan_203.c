#include<stdio.h>
#define size 50
char menu();
char inputChar();
int inputInt();
void checkCharAndNum(int,char);
void drawLine(int,char);
void drawSquare(int,char);
void drawRectangle(int,char);
void drawTriagle(int,char);


int main(){
    char userChoice;
    char C = ' ';
    int N = 0;
      
    do{
        userChoice = menu();
        switch(userChoice){
            case 'c':
            case 'C':
                    printf("\tYou choose enter or change character.\n");
                    C = inputChar();
                    printf("\tYou choose %c as your character.\n",C);
                    printf("\tPlease choose another option if you want.\n\n");
                    break;
            case 'n':
            case 'N':
                    printf("\tYou choose enter or change number.\n");
                    N = inputInt();
                    printf("\tYou choose %d as the number of the character.\n",N);
                    printf("\tPlease choose another option if you want.\n\n");
                    break;
            case 'L':
            case 'l':
                    printf("\tYou choose to draw line.\n");
                    if(N != 0 && C != ' '){
                        drawLine(N, C);
                    }
                    else{
                        printf("\tYou need to initialize  a number and a character.\n");
                    }               
                    printf("\tPlease choose another option if you want.\n\n");
                    break;    
            case 'S':
            case 's':
                    printf("\tYou choose to draw square.\n");
                    if(N != 0 && C != ' '){
                        drawSquare(N, C);
                    }
                    else{
                        printf("\tYou need to initialize  a number and a character.\n");
                    }      
                    printf("\tPlease choose another option if you want.\n\n");
                    break;
            case 'R':
            case 'r':
                    printf("\tYou choose to draw rectangle.\n");
                    if(N != 0 && C != ' '){
                        drawRectangle(N, C);
                    }
                    else{
                        printf("\tYou need to initialize  a number and a character.\n");
                    }                        
                    printf("\tPlease choose another option if you want.\n\n");
                    break;
            case 'T':
            case 't':
                    printf("\tYou choose to draw triangle.\n");
                    if(N != 0 && C != ' '){
                        drawTriagle(N, C);
                    }
                    else{
                        printf("\tYou need to initialize  a number and a character.\n");
                    }  
                    printf("\tPlease choose another option if you want.\n\n");
                    break;
            default:
                    if(userChoice == 'q' || userChoice == 'Q'){
                        printf("\tThank you for using. Byebye.\n");
                    }
                    else{
                        printf("\tInvalid input. Please enter again.\n\n");
                    }                  
        }
    }while(userChoice != 'q' && userChoice != 'Q');
    

    return 0;
}

char menu(){
    char choice, inBuf[size];
    printf("\tMenu Choice                   Input Choices\n");
    printf("\tEnter/Change Character          'C' or 'c'\n");
    printf("\tEnter/Change Number             'N' or 'n'\n");
    printf("\tDraw Line                       'L' or 'l'\n");
    printf("\tDraw Square                     'S' or 's'\n");
    printf("\tDraw Rectangle                  'R' or 'r'\n");
    printf("\tDraw Triangle(Left Justified)   'T' or 't'\n");
    printf("\tQuit Program                    'Q' or 'q'\n\n");
    printf("\tPlease select one of the options: ");
    fgets(inBuf, size, stdin);
    sscanf(inBuf, "%c", &choice);
    return choice;
}

char inputChar(){
    char character, inBuf[size];
    printf("\tPlease enter a character that you like: ");
    fgets(inBuf,size,stdin);
    sscanf(inBuf,"%c",&character);
    return character;
}

int inputInt(){
    int number;
    char inBuf[size];
    do{
    printf("\tPlease enter the number of character that you want to build (between 1 to 15): ");
    fgets(inBuf,size,stdin);
    sscanf(inBuf,"%d",&number);
    if(number < 1 || number > 15){
        printf("\tYou enter an invalid inout.Please enter again.\n");
    }
    }while(number < 1 || number > 15 );
    return number;
}

void checkCharAndNum(int number, char character){
    if((number = 0) && (character == ' ')){
        printf("\tPlease choose the first or second option to initial values or you cannot draw.\n");
    }

}
void drawLine(int number, char character){
    for(int i = 0; i < number; i++){
        printf("\t%c\n",character);
    }
}


void drawSquare(int number, char character){
    for(int i = 0; i < number; i++){
        for(int j = 0; j < number; j++){
            printf("\t%c",character);
        }
        printf("\n");
    }
}

void drawRectangle(int number, char character){
    for(int i = 0; i < number; i++){
        for(int j = 0; j < number + 5; j++){
            printf("\t%c",character);
        }
        printf("\n");
    }
}

void drawTriagle(int number, char character){
    for(int i = 0; i < number ; i++){
        for(int j = 0; j <= i; j++){
            printf("\t%c",character);
        }
        printf("\n");
    }
}
